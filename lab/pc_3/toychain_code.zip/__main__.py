import hashlib

prev_hash = "0000006482ce137edd8b86a58512f9f07838a4ca276645ae90765395b45d6c3f"
name = "ostrich"
nonce = 160650
i = 8
while True:
  test = f"{prev_hash}{name}{nonce}"
  result = hashlib.sha256(test.encode()).hexdigest()
  if result.startswith("0"*i):
    print(test)
    print(result)
    print(nonce)
    break
  nonce += 1
